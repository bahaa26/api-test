<div class="one withsmallpadding ppb_header " style="text-align:center;padding:60px 0 60px 0; ">
    <div class="standard_wrapper">
        <div class="page_content_wrapper">
            <div class="inner">
                <div style="margin:auto;width:100%">
                    <h2 class="ppb_title" style=""> <?php echo e(__('home.company')); ?> <span style="color: #ed2027;"> <?php echo e(__('home.name')); ?> </span> <?php echo e(__('home.choose.one')); ?> <span style="color: #ed2027;"> <?php echo e(__('home.name')); ?> </span></h2>
                    <div class="page_tagline" style=""><?php echo e(__('home.choose.two')); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="one withsmallpadding ppb_text" style="padding-top:0 !important;text-align:center;padding:10px 0 10px 0; margin-bottom: 100px;">
    <div class="standard_wrapper">
        <div class="page_content_wrapper">
            <div class="inner">
                <div class="container">
                    <div class="col-md-3"> 
                        <div class="one_third " style=""><span class="ti-headphone-alt" style="display: block; font-size: 50px; margin-bottom: 20px;"> </span>
                        <h4 ><?php echo e(__('home.choose.icons.one')); ?></h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="one_third " style=""><span class="ti-home" style="display: block; font-size: 50px; margin-bottom: 20px;"> </span>
                            <h4 ><?php echo e(__('home.choose.icons.two')); ?></h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="one_third " style=""><span class="ti-clipboard" style="display: block; font-size: 50px; margin-bottom: 20px;"> </span>
                            <h4 ><?php echo e(__('home.choose.icons.three')); ?></h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="one_third " style=""><span class="ti-map" style="display: block; font-size: 50px; margin-bottom: 20px;"> </span>
                            <h4 ><?php echo e(__('home.choose.icons.four')); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/deebzxsx/public_html/resources/views/home/choose.blade.php ENDPATH**/ ?>