<div class="one withsmallpadding ppb_header " style="text-align:center;padding:60px 0 60px 0;">
    <div class="standard_wrapper">
        <div class="page_content_wrapper">
            <div class="inner">
                <div style="margin:auto;width:100%">
                    <h2 class="ppb_title" style=""><?php echo e(__('home.cars.title')); ?></h2>
                    <div class="page_tagline" style=""><?php echo e(__('home.cars.title2')); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="ppb_car_brand_grid one nopadding ">
    <div class="page_content_wrapper page_main_content sidebar_content full_width fixed_column">
        <div class="standard_wrapper">
            <div id="15722572661666401717" class="portfolio_filter_wrapper gallery grid portrait three_cols" data-columns="3">
                <div class="element grid classic3_cols animated1">
                    <div class="one_third gallery3 grid static filterable portfolio_type themeborder" style="background-image:url(images/toyota_hiace.jpg);">
                        <a class="car_image" href="#"></a>
                        <div class="portfolio_info_wrapper">
                            <h3>Toyota HiAce</h3></div>
                    </div>
                </div>
                <div class="element grid classic3_cols animated2">
                    <div class="one_third gallery3 grid static filterable portfolio_type themeborder" style="background-image:url(images/h1.jpg);">
                        <a class="car_image" href="#"></a>
                        <div class="portfolio_info_wrapper">
                            <h3>H1</h3></div>
                    </div>
                </div>
                <div class="element grid classic3_cols animated3">
                    <div class="one_third gallery3 grid static filterable portfolio_type themeborder" style="background-image:url(images/lancer.jpg);">
                        <a class="car_image" href="#"></a>
                        <div class="portfolio_info_wrapper">
                            <h3>MITSUBISHI LANCER</h3></div>
                    </div>
                </div>
                <!--
                <div class="element grid classic3_cols animated4">
                    <div class="one_third gallery3 grid static filterable portfolio_type themeborder" style="background-image:url(upload/Mercedes-C-Class-Estate-1.jpg);">
                        <a class="car_image" href="#"></a>
                        <div class="portfolio_info_wrapper">
                            <h3>Mercedes Benz</h3></div>
                    </div>
                </div>
                <div class="element grid classic3_cols animated5">
                    <div class="one_third gallery3 grid static filterable portfolio_type themeborder" style="background-image:url(upload/2016-MINI-Cooper-S-Clubman-ALL4.jpg);">
                        <a class="car_image" href="#"></a>
                        <div class="portfolio_info_wrapper">
                            <h3>MINI</h3></div>
                    </div>
                </div>
                <div class="element grid classic3_cols animated6">
                    <div class="one_third gallery3 grid static filterable portfolio_type themeborder" style="background-image:url(upload/P14_0596_a4_rgb-1.jpg);">
                        <a class="car_image" href="#"></a>
                        <div class="portfolio_info_wrapper">
                            <h3>Porsche</h3></div>
                    </div>
                </div>-->
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\deeb\resources\views/home/car.blade.php ENDPATH**/ ?>