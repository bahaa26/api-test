<?php

use App\Http\Controllers\ContactController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::redirect('/', '/ar');
 Route::group(['prefix' => '{lang}', 'middleware' => 'SetLang'], function () {
     Route::get('/', function () {
         return view('app');
     })->name('home');

     Route::get('airport', function () {
         return view('airport');
     })->name('air');

     Route::get('city', function () {
         return view('city');
     })->name('city');

     Route::get('trans', function () {
         return view('trans');
     })->name('trans');

     Route::get('mar', function () {
         return view('mar');
     })->name('mar');

     Route::get('business', function () {
         return view('bus');
     })->name('bus');

     Route::get('conspiracy', function () {
         return view('mat');
     })->name('mat');

     Route::get('about', function () {
         return view('about');
     })->name('about');

     Route::get('contact', function () {
         return view('contact');
     })->name('contact');
 });

 Route::post('contact/send', [ContactController::class, 'send'])->name('send');


