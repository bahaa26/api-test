<?php

return [

    'home' => 'Home',

];
